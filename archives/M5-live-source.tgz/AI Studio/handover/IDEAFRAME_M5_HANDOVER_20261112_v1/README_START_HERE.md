# IDEAFRAME M5 — start here

**M5 IN_PROGRESS.** This is an internal development checkpoint, not a production release, accepted integration module, self-contained installer or backup of private projects.

1. Read the [master engineering handover](docs/M5_MASTER_HANDOVER.md), [requirements traceability](docs/M5_REQUIREMENTS_TRACEABILITY.md), [known issues](docs/M5_KNOWN_ISSUES.md), [security and rights](docs/M5_SECURITY_AND_RIGHTS.md), [status manifest](M5_STATUS_MANIFEST.json) and [dependencies](M5_DEPENDENCIES.json).
2. Follow the [verification protocol](M5_CHECKPOINT_VERIFICATION.md). Run `python3 -I -B '/ABSOLUTE/PACKAGE/tools/verify_package.py' --root '/ABSOLUTE/PACKAGE'`. Retain the external archive/hash receipt on independent trusted media.
3. Actual implementation is under `source/`, with original relative paths. Use the [architecture and exact API catalogue](docs/M5_ARCHITECTURE.md) and [test evidence](docs/M5_TEST_EVIDENCE.md) rather than guessing from historical summaries.
4. Follow the [recovery guide](docs/M5_RECOVERY_GUIDE.md) for fresh isolated restoration, startup and explicit resume. Read the [integration guide](M5_INTEGRATION_GUIDE.md) before archive placement. No `Complete Modules` destination was confirmed and no external copy was made.
5. Use the [next-agent prompt](M5_NEXT_AGENT_PROMPT.md) with a new owner-authorized task; it is not a protected-contract or release waiver.

The recovery artifact preserves the exact 247 authorized source files captured before handover documentation was added. The portable artifact contains those bytes plus three new handover files in its source tree. Each artifact has an independent integrity manifest and archive receipt. Neither contains protected R1, the frozen checkpoint, M4/M6/production, private libraries/customer projects, model weights, native runtimes, SDK binaries or caches. External identities and restoration limits are explicit. Original pinned fonts and OFL notices are included.

The connected poster journey is implemented and narrowly smoke-verified. Full M5 remains incomplete: PNG order, conversational editing, broader formats/fonts/reference/OCR/video, image generation, reel coordination, native Telugu/accessibility/creative-quality acceptance and offline distribution closure remain unresolved or separately gated. Do not use synthetic acceptance grants as permission for real media.

Artifact purpose: PORTABLE DEVELOPMENT HANDOVER; not an accepted completed module.
