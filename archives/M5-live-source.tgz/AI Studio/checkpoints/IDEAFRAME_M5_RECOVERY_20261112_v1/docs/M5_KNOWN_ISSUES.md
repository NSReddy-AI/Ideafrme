# Known issues and dependency-ordered remaining work

## Functional blockers

ISS-01:PNG stacking/interleaving absent. `Workflow._transaction` and `Unified._validate` only accept place/geometry/remove PNG deltas. Define a separately approved new workflow/history version, complete ID permutation/same-universe validation, one atomic before/after transaction, sticky compatibility, explicit reader rejection and one-stepUndo/Redo. Preserve receipts, rights, IDs, base paint order and old exports. Numeric/delete-readd tricks are prohibited.

ISS-02:Conversational atomic editing absent. Universal§8 explicitly calls multi-operation/provenance a future contract. Need selection/ambiguous-target handling, before/after diff, protected-text review, explicitApply/Discard and one atomic reversible action. Current independent geometry/style/text transactions are not an implementation. Shared-content unlink, duplicate, visibility/lock/opacity/crop/mask and broad type styling also need supported transaction/render semantics rather than client-only flags.

## Security/rights blockers

ISS-05:BrandB complete-format scope remains partial. Narrow PNG is live; SVG/otherimages/uploadedfonts remain disabled. Each future format requires its own allowlist/decoder/resource/active-reference/font-shaping/rights/profile qualification. Metadata registration is not use permission. Unknown hard brand rules refuse. R2 image/OCR/video boundary remains unqualified; do not generalize PNG approval or old Phase2 sandbox probes.

## Integration blockers

ISS-07:Current optional inference and PNG helper use fixed absolute runtime/model/rpath/build locations. Portable source is not independently runnable without these artifacts; relocation requires reviewed loader/profile/identity compatibility and qualification. Old Phase2 requires external private HyperFrames dependencies. No M4/M6 adapter or authorized engine access; G5 and separately gated Reference/R2 remain open.

ISS-08:Historical docs conflict:rootREADME describes early core, no UI/models; early handoffs say no editor/media; LOCAL_STUDIO_START says registered assets not applied; PROJECT_BINDING_CONTRACT says no automatic colors/fonts and hard rules only displayed; PNG dependency/build records retain live_placement_enabled=false; quarantine v1 alwaysNO-GO;2A–2E AI integrationNO-GO; old unified handoff says controller unchanged. Current source +2F/2G +BrandA +qualifiedPNGv2/v3 +functional sprint supersede only their scopes. Do not rewrite historical records or infer all gates closed.

## Acceptance-only gaps

ISS-03:Native Telugu speaker review/OSIME composition and complete accessibility are unverified. ExactUnicode copying is not Telugu comprehension; browser font probes are not editorial language approval. New PNG keyboard paths are implemented but latest pointer smoke is not a keyboard-only/screen-reader audit.

ISS-04:AI current hybrid uses two text roles and three generic top/middle/bottom relationships. Model supplies editorial interpretation, not all geometry/rationale wording. Avoid claiming unlimited creative novelty, arbitrary instruction satisfaction or human originality approval. SlowCPU≈1–3minutes; earlier14B peaks≈12–14 GiB. No approved Metal fix or source-bundle closure. Existing Qwen8B/semantic14B failures stay failures; hybrid is a separate labelled contract, not changed thresholds.

Recovery:application crash/ENOSPC/sync simulations and restart pass only documented conditions. No physical power-loss certification, hostile filesystem race-proofing, general atomic-replacement proof or authenticated reviewer identity. Missing/corruptHEAD requires explicit selected recovery copy; never auto-overwrite primaries/.previous/history/exports. Quota exhaustion refuses with retained evidence; no cleanup policy.

## Offline/distribution blockers

ISS-06:Retained wrapper/runtime/source metadata is not clean independent rebuild. RustCargo, LLVMbootstrap, SDK/Python/browser/native dependencies, matching model-tokenizer/conversion provenance, complete notices, sourceoffers where applicable and owner first-party license/release signoff remain open. The9.276 GB model cannot fit a256 MiB media deployment target; those are separate product components/requirements, not interchangeable claims.

ISS-09:Checkpoint intentionally excludes protected R1 and privatebrand/project data, all nonselected runtime state/nativebinaries/models/caches. Preserve them separately with owner authorization and exact identities. This package cannot restore user sessions or protected R1 or cold-provision the whole machine. Requirement inventory marks that unknown/exclusion rather than complete.

ISS-10:Complete Modules not found/confirmed from project docs, parent structure and available exact-nameSpotlight lookup. No protected directory was entered, no location guessed, no external copy made. Owner must identify the destination; never overwrite an existing module or conflate archive placement with release.

## Deferred cosmetic/performance work

Improve responsive density, inspector/navigation ergonomics, full poster screenshot framing and noncritical polish only after main functional gaps. Performance profiling/acceleration is separate from re-running random model samples. Keep targeted checks per changed boundary and one focused final journey; avoid repeated broad regressions.

## Recommended execution order

1. Verify package and restore exact authorized source into a fresh approved isolated copy; confirm external dependencies/no other writer. Read master, status, security and source-associated evidence before edits.
2. Resolve narrow PNG-order contract authorization; implement/validate complete versioned reorder without touching protected content; preserve unified editing/export.
3. Resolve essential conversational/advanced-inspector contract decisions without pretending fields exist; implement safe approved transactions with one-stepundo/context/rights checks.
4. Complete native TeluguIME, keyboard/accessibility and broader creative-quality acceptance; ordinary defects within approved boundaries can be fixed autonomously, not repeated design reviews.
5. Seek separate qualified-format/Reference/R2/image-model/reel-engine authorization where required. Keep requirements visible; do not bridge M4/M6 or process unqualified media as a shortcut.
6. Close offline/legal/build provisioning, then run consolidated final functional/security/rights/compatibility acceptance against exact source and artifacts.
7. Only declareM5 complete when every essential committed requirement is implemented and the full authorized end-to-end workflow works; owner approves integration/release separately. No percentage-complete claim.
