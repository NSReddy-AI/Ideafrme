# Test evidence and verification boundaries

Packaging does not run product tests, inference, decoding, browser acceptance or a broad regression. Existing records below are retained statements with exact source association where available. A matching subset does not certify all current files. Counts from overlapping historical reruns are NOT summed into a global number.

## core

Original: `.runtime/test-results.txt`; present=True; packaged: `evidence/retained/test-results.txt`.

Historical Phase1 37 cases; later core extensions were not present.

No machine-readable whole-current-source test association inferred.

## phase2

Original: `output/phase2/acceptance.json`; present=True; packaged: `evidence/retained/phase2/acceptance.json`.

Historical prototype4drafts/comparisons/repeats; NOT current hostile-media qualification.

Source association: 0matching and 0different scoped files; see JSON exact lists.

## manual

Original: `docs/STUDIO_UI_HANDOFF.md`; present=True; packaged: `source/docs/STUDIO_UI_HANDOFF.md`.

Historical28 manual UI tests; not rerun.

No machine-readable whole-current-source test association inferred.

## visual

Original: `docs/VISUAL_POSTER_HANDOFF.md`; present=True; packaged: `source/docs/VISUAL_POSTER_HANDOFF.md`.

Historical43 automated/14browser checks; not a current whole-suite rerun.

No machine-readable whole-current-source test association inferred.

## resume

Original: `docs/VISUAL_REORDER_RESUME_CONTRACT.md`; present=True; packaged: `source/docs/VISUAL_REORDER_RESUME_CONTRACT.md`.

Read actual contracts and individual retained evidence references; not fresh power-loss testing.

No machine-readable whole-current-source test association inferred.

## geometry

Original: `docs/VISUAL_GEOMETRY_HANDOFF.md`; present=True; packaged: `source/docs/VISUAL_GEOMETRY_HANDOFF.md`.

Historical targeted history-v3/geometry evidence; not rerun.

No machine-readable whole-current-source test association inferred.

## text

Original: `docs/VISUAL_TEXT_COMPLETION_HANDOFF.md`; present=True; packaged: `source/docs/VISUAL_TEXT_COMPLETION_HANDOFF.md`.

Composition guards/keyboard checks; not native IME/human language signoff.

No machine-readable whole-current-source test association inferred.

## home

Original: `docs/M5_HOME_PROJECTS_HANDOFF.md`; present=True; packaged: `source/docs/M5_HOME_PROJECTS_HANDOFF.md`.

Historical Home/Projects focused checks.

No machine-readable whole-current-source test association inferred.

## brand

Original: `docs/BRAND_ASSET_FOUNDATION_HANDOFF.md`; present=True; packaged: `source/docs/BRAND_ASSET_FOUNDATION_HANDOFF.md`.

Historical SQLite/record/rights tests, not private-library legal audit.

No machine-readable whole-current-source test association inferred.

## brand-portability

Original: `docs/BRAND_LIBRARY_PORTABILITY_HANDOFF.md`; present=True; packaged: `source/docs/BRAND_LIBRARY_PORTABILITY_HANDOFF.md`.

Historical package-preview/restore rights and atomicity evidence.

No machine-readable whole-current-source test association inferred.

## binding

Original: `docs/PROJECT_BINDING_HANDOFF.md`; present=True; packaged: `source/docs/PROJECT_BINDING_HANDOFF.md`.

Historical pair publication/recovery/identity tests; not physical power-loss proof.

No machine-readable whole-current-source test association inferred.

## brand-a

Original: `docs/BRAND_APPLICATION_A.md`; present=True; packaged: `source/docs/BRAND_APPLICATION_A.md`.

Historical exact-rule/palette/font/refusal and integration checks.

No machine-readable whole-current-source test association inferred.

## director

Original: `docs/CREATIVE_DIRECTOR_PHASE1.md`; present=True; packaged: `source/docs/CREATIVE_DIRECTOR_PHASE1.md`.

Historical deterministic planning, not AI.

No machine-readable whole-current-source test association inferred.

## hybrid-f

Original: `docs/CREATIVE_DIRECTOR_PHASE2F.md`; present=True; packaged: `source/docs/CREATIVE_DIRECTOR_PHASE2F.md`.

12 focused tests,2actual language runs; source and measurements bound to historical identities.

No machine-readable whole-current-source test association inferred.

## hybrid-g

Original: `.runtime/studio-ui/visual-director-2g-01/completion-final.json`; present=True; packaged: `evidence/retained/studio-ui/visual-director-2g-01/completion-final.json`.

Final36 targeted Python/34 browser-export checks as recorded; not rerun or added to current25.

Source association: 0matching and 0different scoped files; see JSON exact lists.

## png-security

Original: `.runtime/png-first-001/security-02/results.json`; present=True; packaged: `evidence/retained/png-first-001/security-02/results.json`.

22 distinct base decoder/security checks,0failures; older controller source identity.

Source association: 4matching and 3different scoped files; see JSON exact lists.

## png-lifecycle

Original: `.runtime/png-first-001/lifecycle-final/results.json`; present=True; packaged: `evidence/retained/png-first-001/lifecycle-final/results.json`.

4 additional lifecycle/accounting checks; do not double-count reruns.

Source association: 8matching and 6different scoped files; see JSON exact lists.

## png-workflow

Original: `.runtime/studio-ui/visual-png-workflow-tests-final/results.json`; present=True; packaged: `evidence/retained/studio-ui/visual-png-workflow-tests-final/results.json`.

18 workflow checks.22+4+18=44 historical distinct tests only.

Source association: 8matching and 6different scoped files; see JSON exact lists.

## png-unified

Original: `.runtime/png-unified-001/completion.json`; present=True; packaged: `evidence/retained/png-unified-001/completion.json`.

12 targeted Python+9HTTP and browser/export/restart records; historical pre-sprint UI identities.

Source association: 0matching and 0different scoped files; see JSON exact lists.

## sprint

Original: `.runtime/m5-functional-sprint-01/completion.json`; present=True; packaged: `evidence/retained/m5-functional-sprint-01/completion.json`.

11product/hash+4decoder+6JS+4HTTP=25 targeted;5JS+5Python=10syntax; actualAI103.9s/96.7s;19retained files unchanged.

Source association: 247matching and 0different scoped files; see JSON exact lists.

## agent

Original: `docs/MEDIA_AGENT_COMPLETION_HANDOFF.md`; present=True; packaged: `source/docs/MEDIA_AGENT_COMPLETION_HANDOFF.md`.

Synthetic lifecycle/protocol/package tests; never general media qualification.

No machine-readable whole-current-source test association inferred.

## media-foundation

Original: `docs/MEDIA_WORKFLOW_FOUNDATION.md`; present=True; packaged: `source/docs/MEDIA_WORKFLOW_FOUNDATION.md`.

22 quarantine/admission checks; live processing unconditionally disabled.

No machine-readable whole-current-source test association inferred.

## r2-design

Original: `docs/R2_ARCHITECTURE_DECISION_RECORD.md`; present=True; packaged: `source/docs/R2_ARCHITECTURE_DECISION_RECORD.md`.

GateA BLOCKED, GateB contracts provisional, GateC dependencies, GateD evaluation; no actualR2accepted.

No machine-readable whole-current-source test association inferred.

## local

Original: `docs/M5_LOCAL_PRODUCT_HANDOFF.md`; present=True; packaged: `source/docs/M5_LOCAL_PRODUCT_HANDOFF.md`.

Historical9 startup checks, not offline rebuild closure.

No machine-readable whole-current-source test association inferred.

## dependency

Original: `docs/PNG_SANDBOX_DEPENDENCIES.json`; present=True; packaged: `source/docs/PNG_SANDBOX_DEPENDENCIES.json`.

Recorded exact licensing/security/build inputs; not a new current-upstream audit.

Source association: 0matching and 0different scoped files; see JSON exact lists.

## excluded-r1

Original: `None`; present=False; packaged: `not copied / this checkpoint verification`.

Protected R1 content/tests/handoffs not read or copied; acceptance claims not independently reviewed here.

No machine-readable whole-current-source test association inferred.

## checkpoint

Original: `None`; present=False; packaged: `not copied / this checkpoint verification`.

This task verifies copy/hash/ZIP/extraction/document paths/source preservation only; no product tests executed.

No machine-readable whole-current-source test association inferred.

## Latest working journey

Source confirms product.create uses binding_workflow.create; product.mjs opens existing hybrid controls; hybrid_jobs verifies pinned artifacts and publishes selected paired drafts; media_bridge forks explicit Unified; media.mjs routes accepted edits/scenes/export to existing envelope; media_gestures commits one captured-head geometry delta; app.run autosaves canonical edits; scene/QA/export/reopen use existing sources. Latest evidence records actual model103.9s then96.7s after a technicalRSS integration fix, three differentiated concepts, PNGplace/drag/resize/Undo/Redo, textedit/Undo/Redo, draftSVG+PNG and full service stop/resume.19 retained files/state unchanged; SVG6adcdc1304752d600650dba4ea6cfd9e6bd6171d585d9c356649300973a4f8ff; PNGc3432468a11d8a4624d0216d0f8d85a26b53dc4443c6b8b8e4c2f8015576b62c. Browser parity is a trusted client measurement, not independent server raster.

Initial failures remain visible:first fixture library wrongruntime-root refusal; initial PNG controller RSS refusal, no publication; one restartport8778address-in-use then8779resume; stale temporarytabs/locator retargeting. A raw SVG substring assertion initially failed because text was split across script tspans; parsed concatenated textnodes matched exactEnglish/Telugu andno product defect was inferred. These attempts are not passing tests. The second AI execution was an affected integration recheck, not retry-to-manufacture language validity.

22basePNG+4additional lifecycle+18workflow=44 historical distinct tests;12unified+9HTTP are separate integration evidence.2G's36Python+34browser/export=70 are historical categories, not70new currenttests. Latest25targeted+10syntax are not added to historical reruns. Fault injections are not actualOScrash, diskexhaustion or physical power loss. No latest native Telugu IME, full accessibility, broad creative quality, malicious native host or cleanoffline provisioning acceptance.
