# Restart, source restoration and recovery

## Understand scope first

Exact recovery means the listed source bytes/modes are preserved. It does not mean private projects/brandlibraries/protected R1 or externalPython/browser/model/Wasmtime/SDKs are included. Keep existing original runtime/project data untouched; this package is on the same disk until owner copies it to independent media. SHA256 detects corruption, not malicious replacement of both data and manifests. Archive receipt is an external trust anchor to retain separately; not a digital signature.

## Verify without writes

```sh
python3 -I -B '/ABSOLUTE/PACKAGE/tools/verify_package.py' --root '/ABSOLUTE/PACKAGE'
```

This checks structure, every payload digest/size/mode, missing/unexpected files and documented status schema; it prints external dependencies without opening outside paths, installing or launching anything. It excludes only the authoritative root manifest itself from self-hashing; archive receipt records its hash and full archive hash. Preserve .zip.sha256 receipt separately. `manifests/CAPTURED_SOURCE.json` binds the original source, not generateddocs.

## Restore into a fresh isolated directory

```sh
python3 -I -B '/ABSOLUTE/PACKAGE/tools/restore_source.py' --root '/ABSOLUTE/PACKAGE' --authorized-root '/ABSOLUTE/OWNER_APPROVED/ISOLATED/WORKAREA' --destination '/ABSOLUTE/OWNER_APPROVED/ISOLATED/WORKAREA/NEW_UNUSED_M5'
```

It first verifies the full package, requires an existing real approvedroot and nonexistent strict child destination, rejects traversal/symlinks/aliases and exclusively creates/copies only source-relative paths with recordedmodes. It never executes product code or writes external dependencies. For exactpre-handoverbytes use recovery artifact; portable source adds master/status documentation. Do not use a production/M4/M6/frozen/R1 directory as either parameter. No restoration into an existing working copy/merge/overwrite is supported. Missing dependencies remain missing, not auto-downloaded. Wrong destination/sourcealias refuses; incomplete failure output is retained, not silently deleted.

## Check and launch

Original workspace:
`/Users/Nadish/projects/AI Video Editor./Codex/AI Studio`

```sh
cd '/Users/Nadish/projects/AI Video Editor./Codex/AI Studio'
python3 -I -B tools/studio_local.py check
python3 -B -m visual_poster_studio --port 8766
```

Open `http://127.0.0.1:8766`. Alternative `'/Users/Nadish/projects/AI Video Editor./Codex/AI Studio/Start Studio.command' start --port 8766` starts from anycwd. `--port 0` selects a free port without evicting anotherprocess. No package manager/install/AI/backend is automatically launched. Check verifies local font source/SQLite presence, not browser/modelexecution, advisories or offline distribution. Original model/PNG artifact paths and native rpath must match or remain disabled; relocation needs separately authorized qualification, not editing immutable manifests. Tests may contain original workspace anchors; inspect before running restored tests.

Fresh launch creates a new Visual-owned session. For existing normal owned data:

```sh
python3 -B -m visual_poster_studio --resume --root '/ABSOLUTE/EXISTING/OWNED/VISUAL_SESSION' --port 8766
```

OSwriterlock/Visual and manual identity/fontprofile/document/history/context/exports validate before projectaccess. Resume is explicit; never adopt a legacy or acceptance-evidence root. Mainservice currently uses default brandlibrary under workspace/.runtime/studio-ui/brand-library; the synthetic sprintsmoke injected its own fixture library and is not realbrandpermission or recommendedproductiondata. Source-onlyrestore does not recreateprivate projects. Owner must make a separately authorizedconsistent privatebackup; do not copy independentlyselectedcreative/bindingfiles or use a testsuite as a restoretool.

Stop with Ctrl+C in the terminal that owns the service and wait for controller shutdown/writerlockrelease. Do not kill arbitrary ports/processes. Inferencecancel/close confirms childtermination; faults requireexplicitdiagnosis, no auto-restart. Server printsstartup errors; UI displaysapplicationfailures. Inspect owned session/hybrid-jobs/<id>/{status, termination, command}.json andstdout/stderr, pendingjournal/pair/mediaHEAD throughread-onlytools. Do not publish diagnostic/privatebriefs outside authorizedchannels.

## Explicit recovery commands

Unbound Visual journal:stopservice;`python3 -B -m visual_poster_studio --resume --root '<ownedsession>' --recover-copy '<projectUUID>' --candidate after`. This creates a new session; selectedlaterchangesexcluded. Immutablecheckpoint:read `python3 -B -m visual_poster_studio.checkpoint_restore --help`; explicit source/checkpoint/acknowledgeloss required; boundprojects refuse rawlegacyrestore. Pairedbindings:read `python3 -B -m visual_poster_studio.binding_recover --help`; select one validatedpaircommit and freshdestination, not separatebinding/document generations. PNG:mainUI listsvalidatedcandidates and recoversselectedcopy withacknowledgement; CLI/library recover_copy retains source and excludeslaterchanges/oldexports. Do not mutateprimary/.previous/HEAD or overwritecurrentapprovedhistory to repair.

Commandhelps here are instructions, not executedthispackagingtask. Always inspect captured CLI's argparse before a destructive/recoverycommand. Unknownversions/corruptHEAD/unsupportedfsyncfailclosed. Recoverybudget128 MiB, mediawhole-root128 MiB, exportquotas and orphanedartifacts remaincounted; exhaustiondoesnotauthorizecleanup. Physicalpowerloss unverified.

## Minimal verification after resuming development

Do not run tests solely to unpack/read handover. After owner-authorized changes, use source-relevantfresh evidence only. Existing exact targetedcommand (writesprojects, not read-only):`python3 -I -B tools/run_m5_sprint_checks.py --evidence '<workspace>/.runtime/studio-ui/NEW_UNUSED_CHECK_ROOT'`. AI generation/PNGdecoder/browser checks require their acceptedruntime and deliberate test scope; do not run oldbroad orfixed-output scripts blindly. Never useacceptancefixturelegalgrants as real asset permissions.
