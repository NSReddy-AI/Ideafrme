"""Read-only package verification; no imports/startup of product code or external reads."""
import argparse,hashlib,json,os,stat,sys
from pathlib import Path,PurePosixPath

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('Duplicate JSON key')
  d[k]=v
 return d
def load(p):return json.loads(p.read_text(encoding='utf-8'),object_pairs_hook=pairs)
def verify(root):
 root=Path(root)
 if not root.is_absolute() or any(p.is_symlink() for p in (root,*root.parents)) or not root.is_dir():raise ValueError('Real absolute package root required')
 manifest=load(root/'M5_SOURCE_MANIFEST.json')
 if manifest['format']!='ideaframe-m5-source-manifest@1' or manifest['self_hash_exclusion']!=['M5_SOURCE_MANIFEST.json']:raise ValueError('Unsupported integrity format')
 entries=manifest['files'];actual={};errors=[]
 for directory,dirs,files in os.walk(root,followlinks=False):
  for n in dirs:
   if (Path(directory)/n).is_symlink():errors.append('symlink-directory:'+n)
  for n in files:
   p=Path(directory)/n;rel=p.relative_to(root).as_posix()
   if p.is_symlink() or not p.is_file() or p.stat().st_nlink!=1:errors.append('nonregular/aliased:'+rel);continue
   if rel=='M5_SOURCE_MANIFEST.json':continue
   actual[rel]=p
 for n,item in entries.items():
  path=PurePosixPath(n)
  if path.is_absolute() or '\\' in n or ':' in n or any(s in ('','.','..') for s in n.split('/')):errors.append('unsafe-manifest-path:'+n);continue
  p=actual.get(n)
  if p is None:errors.append('missing:'+n);continue
  if p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256']:errors.append('digest/size:'+n)
  if stat.S_IMODE(p.stat().st_mode)!=item['mode']:errors.append('mode:'+n)
 errors.extend('unexpected:'+n for n in actual if n not in entries)
 for n in ['README_START_HERE.md','M5_STATUS_MANIFEST.json','M5_DEPENDENCIES.json','M5_CHECKPOINT_VERIFICATION.md','tools/verify_package.py','tools/restore_source.py','manifests/CAPTURED_SOURCE.json','docs/M5_MASTER_HANDOVER.md']:
  if n not in entries:errors.append('required:'+n)
 status=load(root/'M5_STATUS_MANIFEST.json');schema=load(root/'docs/M5_STATUS_SCHEMA.json')
 if set(status)!=set(schema['required']) or status['format']!='ideaframe-m5-status@1' or status['schema_version']!=1 or status['overall_status']!='IN_PROGRESS':errors.append('status-schema')
 ids=[]
 for q in status['requirement_inventory']:
  ids.append(q['id'])
  if q['status'] not in status['classification_enum']:errors.append('classification:'+q['id'])
  for n in q['source_files']:
   if not (root/'source'/n).is_file() and not (root/n).is_file():errors.append('requirement-source:'+q['id']+':'+n)
 if len(ids)!=len(set(ids)):errors.append('duplicate requirement ID')
 dep=load(root/'M5_DEPENDENCIES.json')
 return {'verified':not errors,'kind':manifest['purpose'],'files_checked':len(entries),'source_files':sum(n.startswith('source/') for n in entries),'manifest_sha256':sha(root/'M5_SOURCE_MANIFEST.json'),'errors':errors,'external_dependencies_not_included':[{'id':x['id'],'expected_path':x['expected_path'],'sha256':x['sha256'],'freshly_checked':x['identity_freshly_checked']} for x in dep['external_artifacts']],'scope':'No product tests,external dependency checks,network,decoding,AI,private state or protected workspace access;SHA256 is not publisher authentication.'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
 try:r=verify(a.root)
 except Exception as e:r={'verified':False,'errors':[str(e)]}
 print(json.dumps(r,indent=2));return 0 if r['verified'] else 1
if __name__=='__main__':raise SystemExit(main())
