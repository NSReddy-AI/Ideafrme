"""Explicit fresh-source restoration after full verification;never overwrite/merge or run product code."""
import argparse,importlib.util,os,shutil,stat
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--authorized-root',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
 for v in (a.root,a.authorized_root,a.destination):
  if not v.is_absolute() or '..' in v.parts or any(q.is_symlink() for q in (v,*v.parents)):raise ValueError('Canonical absolute no-symlink paths required')
 if not a.authorized_root.is_dir() or a.destination.exists() or not a.destination.is_relative_to(a.authorized_root) or a.destination==a.authorized_root:raise ValueError('New strict child of explicit approved root required')
 if a.destination.is_relative_to(a.root) or a.root.is_relative_to(a.destination):raise ValueError('No package/source alias')
 spec=importlib.util.spec_from_file_location('verify_package',a.root/'tools/verify_package.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);report=v.verify(a.root)
 if not report['verified']:raise ValueError(str(report['errors']))
 manifest=v.load(a.root/'M5_SOURCE_MANIFEST.json');names=[n for n in manifest['files'] if n.startswith('source/')]
 a.destination.mkdir(mode=0o700,parents=False,exist_ok=False)
 for name in names:
  src=a.root/name;dst=a.destination/Path(name).relative_to('source');dst.parent.mkdir(parents=True,exist_ok=True)
  with src.open('rb') as i,dst.open('xb') as o:shutil.copyfileobj(i,o,65536)
  dst.chmod(manifest['files'][name]['mode'])
  if v.sha(dst)!=manifest['files'][name]['sha256']:raise ValueError('Restore identity failed;incomplete destination retained')
 print('RESTORED '+str(len(names))+' exact source files to '+str(a.destination)+';external runtime/private state NOT restored. No product code executed.')
if __name__=='__main__':main()
